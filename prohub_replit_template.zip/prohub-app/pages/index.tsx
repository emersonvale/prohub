export default function Home() {
  return <div className="p-8 text-xl">Bem-vindo à PROHUB!</div>
}